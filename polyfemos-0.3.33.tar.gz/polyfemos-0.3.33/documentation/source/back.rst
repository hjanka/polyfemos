
Backend modules
===============

.. autosummary:: 
   :toctree: autogen
   :nosignatures:

   polyfemos.back.filewriter
   polyfemos.back.interpreter
   polyfemos.back.main
   polyfemos.back.parameter
   polyfemos.back.seismic.edlogreader
   polyfemos.back.seismic.lumberjack
   polyfemos.back.seismic.scanner
   polyfemos.back.station




.. polyfemos documentation master file, created by
   sphinx-quickstart on Wed Aug 14 09:38:22 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


polyfemos documentation
=======================



.. toctree::
   :maxdepth: 3
   :caption: readme

   polyfemos_readme_0_general.rst
   polyfemos_readme_1_setup.rst
   polyfemos_readme_2_backend.rst
   polyfemos_readme_3_frontend.rst
   polyfemos_readme_4_add_station.rst
   polyfemos_readme_5_sohemailer.rst


.. toctree::
   :maxdepth: 2
   :caption: modules

   back
   front
   other



indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

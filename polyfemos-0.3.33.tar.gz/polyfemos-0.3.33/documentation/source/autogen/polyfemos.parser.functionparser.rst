
polyfemos.parser.functionparser
===============================

.. currentmodule:: polyfemos.parser.functionparser

.. automodule:: polyfemos.parser.functionparser

   .. comment to end block






    
        
    
    
        
    



.. rubric:: Public Functions


.. autofunction:: compose
.. autofunction:: function_from_str























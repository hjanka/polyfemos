
polyfemos.almanac.utils
=======================

.. currentmodule:: polyfemos.almanac.utils

.. automodule:: polyfemos.almanac.utils

   .. comment to end block






    
        
    
    
        
    



.. rubric:: Public Functions


.. autofunction:: get_jY
.. autofunction:: parse_date
























polyfemos.back.filewriter.FileWriter
====================================

.. currentmodule:: polyfemos.back.filewriter

.. autoclass:: FileWriter
    :show-inheritance:

    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    .. rubric:: Public Methods

    
    .. automethod:: __init__
    .. automethod:: append_and_write_data
    .. automethod:: append_data
    .. automethod:: append_line
    .. automethod:: get_filename
    .. automethod:: update_header
    .. automethod:: write_files
    


    

    

    


|
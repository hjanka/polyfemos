
polyfemos.almanac.timer.Timers
==============================

.. currentmodule:: polyfemos.almanac.timer

.. autoclass:: Timers
    :show-inheritance:

    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    .. rubric:: Public Methods

    
    .. automethod:: __init__
    .. automethod:: start
    .. automethod:: stop
    


    

    
    .. rubric:: Special Methods

    
    .. automethod:: __getitem__
    .. automethod:: __setitem__
    .. automethod:: __str__
    

    


|
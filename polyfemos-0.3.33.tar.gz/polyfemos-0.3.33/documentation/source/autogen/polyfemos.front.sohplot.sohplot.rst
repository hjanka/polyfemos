
polyfemos.front.sohplot.sohplot
===============================

.. currentmodule:: polyfemos.front.sohplot.sohplot

.. automodule:: polyfemos.front.sohplot.sohplot

   .. comment to end block






    
        
    
    
        
    





.. rubric:: Private Functions


.. autofunction:: _get_line_source
.. autofunction:: _plot_line_source








.. rubric:: Classes

.. autosummary::
    :toctree: .
    
    SOHPlot















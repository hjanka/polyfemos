
polyfemos.back.main
===================

.. currentmodule:: polyfemos.back.main

.. automodule:: polyfemos.back.main

   .. comment to end block






    
        
    
    
        
    



.. rubric:: Public Functions


.. autofunction:: main
.. autofunction:: readconf























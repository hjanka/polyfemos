
polyfemos.front.sohplot.sohplot.SOHPlot
=======================================

.. currentmodule:: polyfemos.front.sohplot.sohplot

.. autoclass:: SOHPlot
    :show-inheritance:

    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    .. rubric:: Public Methods

    
    .. automethod:: __init__
    .. automethod:: get_info
    .. automethod:: get_plot_components
    .. automethod:: get_statistics_dict
    .. automethod:: get_statistics_table
    


    
    .. rubric:: Private Methods

    
    .. automethod:: _get_csv_filepath
    .. automethod:: _get_filepath
    .. automethod:: _get_plot
    .. automethod:: _get_stf_filepath
    .. automethod:: _read_csv_data
    .. automethod:: _read_header
    .. automethod:: _read_stf_data
    

    

    


|
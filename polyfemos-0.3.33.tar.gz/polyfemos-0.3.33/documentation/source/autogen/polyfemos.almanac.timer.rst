
polyfemos.almanac.timer
=======================

.. currentmodule:: polyfemos.almanac.timer

.. automodule:: polyfemos.almanac.timer

   .. comment to end block






    
        
    



.. rubric:: Public Functions


.. autofunction:: timed











.. rubric:: Classes

.. autosummary::
    :toctree: .
    
    Timer
    Timers















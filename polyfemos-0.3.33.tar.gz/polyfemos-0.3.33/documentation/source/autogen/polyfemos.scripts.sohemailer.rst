
polyfemos.scripts.sohemailer
============================

.. currentmodule:: polyfemos.scripts.sohemailer

.. automodule:: polyfemos.scripts.sohemailer

   .. comment to end block






    
        
    
    
        
    



.. rubric:: Public Functions


.. autofunction:: main
.. autofunction:: send_email
























polyfemos.almanac.timer.Timer
=============================

.. currentmodule:: polyfemos.almanac.timer

.. autoclass:: Timer
    :show-inheritance:

    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    .. rubric:: Public Methods

    
    .. automethod:: __init__
    .. automethod:: lap
    .. automethod:: reset
    .. automethod:: start
    .. automethod:: stop
    


    

    
    .. rubric:: Special Methods

    
    .. automethod:: __str__
    

    


|
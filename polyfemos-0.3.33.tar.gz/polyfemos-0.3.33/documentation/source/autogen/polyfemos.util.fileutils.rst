
polyfemos.util.fileutils
========================

.. currentmodule:: polyfemos.util.fileutils

.. automodule:: polyfemos.util.fileutils

   .. comment to end block






    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    



.. rubric:: Public Functions


.. autofunction:: append_to_file
.. autofunction:: check_dirpath
.. autofunction:: check_filepath
.. autofunction:: check_path
.. autofunction:: create_missing_folders
.. autofunction:: get_stream
.. autofunction:: invalid_mseed
.. autofunction:: load_obj
.. autofunction:: load_yaml
.. autofunction:: read_csv
.. autofunction:: read_file
.. autofunction:: render_template
.. autofunction:: rowsof
.. autofunction:: save_obj
.. autofunction:: write_csv
.. autofunction:: write_file
























polyfemos.back.filewriter.STFWriter
===================================

.. currentmodule:: polyfemos.back.filewriter

.. autoclass:: STFWriter
    :show-inheritance:

    

    
    
    
    
    
    
    
    
    
    

    
    .. rubric:: Public Methods

    
    .. automethod:: __init__
    .. automethod:: append_line
    


    

    

    


|
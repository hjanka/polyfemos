
polyfemos.parser.typeoperator
=============================

.. currentmodule:: polyfemos.parser.typeoperator

.. automodule:: polyfemos.parser.typeoperator

   .. comment to end block






    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    



.. rubric:: Public Functions


.. autofunction:: NaN2None
.. autofunction:: anything
.. autofunction:: bool_
.. autofunction:: check_type
.. autofunction:: dict_
.. autofunction:: filepath
.. autofunction:: float_
.. autofunction:: floatlist
.. autofunction:: function
.. autofunction:: getNaN
.. autofunction:: int_
.. autofunction:: intlist
.. autofunction:: isNaN
.. autofunction:: isStrNaN
.. autofunction:: list_
.. autofunction:: literal_eval
.. autofunction:: ordinal
.. autofunction:: replaceNaN
.. autofunction:: staticfilepath
.. autofunction:: strNaN
.. autofunction:: str_
.. autofunction:: strlist
.. autofunction:: utcdatetime
.. autofunction:: var





.. rubric:: Private Functions


.. autofunction:: _get_offset




















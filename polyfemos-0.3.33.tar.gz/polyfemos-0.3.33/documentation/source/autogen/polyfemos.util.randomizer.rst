
polyfemos.util.randomizer
=========================

.. currentmodule:: polyfemos.util.randomizer

.. automodule:: polyfemos.util.randomizer

   .. comment to end block






    
        
    
    
        
    



.. rubric:: Public Functions


.. autofunction:: generate_secret_key
.. autofunction:: get_secret_key























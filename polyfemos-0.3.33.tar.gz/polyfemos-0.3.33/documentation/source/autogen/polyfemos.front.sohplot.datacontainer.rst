
polyfemos.front.sohplot.datacontainer
=====================================

.. currentmodule:: polyfemos.front.sohplot.datacontainer

.. automodule:: polyfemos.front.sohplot.datacontainer

   .. comment to end block






    
        
    
    
        
    
    
        
    
    
        
    
    
        
    



.. rubric:: Public Functions


.. autofunction:: remove_timezone
.. autofunction:: remove_timezone_other
.. autofunction:: remove_timezone_py36
.. autofunction:: remove_timezone_py37





.. rubric:: Private Functions


.. autofunction:: _track_datalen








.. rubric:: Classes

.. autosummary::
    :toctree: .
    
    DataContainer
    DataPoint
















polyfemos.back.station.Station
==============================

.. currentmodule:: polyfemos.back.station

.. autoclass:: Station
    :show-inheritance:

    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    .. rubric:: Public Methods

    
    .. automethod:: __init__
    .. automethod:: add_parameter
    .. automethod:: covers_time
    .. automethod:: create_header
    .. automethod:: filter_parameters
    .. automethod:: get_header
    .. automethod:: get_id
    


    
    .. rubric:: Private Methods

    
    .. automethod:: _add_to_header
    .. automethod:: _compare
    

    
    .. rubric:: Special Methods

    
    .. automethod:: __eq__
    .. automethod:: __ge__
    .. automethod:: __gt__
    .. automethod:: __le__
    .. automethod:: __len__
    .. automethod:: __lt__
    .. automethod:: __ne__
    .. automethod:: __str__
    

    


|
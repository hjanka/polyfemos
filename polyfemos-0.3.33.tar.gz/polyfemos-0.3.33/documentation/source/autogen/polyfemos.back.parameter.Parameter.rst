
polyfemos.back.parameter.Parameter
==================================

.. currentmodule:: polyfemos.back.parameter

.. autoclass:: Parameter
    :show-inheritance:

    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    .. rubric:: Public Methods

    
    .. automethod:: __init__
    .. automethod:: create_alertfunc
    .. automethod:: create_header_field
    .. automethod:: generate_header
    


    

    
    .. rubric:: Special Methods

    
    .. automethod:: __getitem__
    .. automethod:: __str__
    

    


|

polyfemos.front.sohplot.offsets.UWVOffsets
==========================================

.. currentmodule:: polyfemos.front.sohplot.offsets

.. autoclass:: UWVOffsets
    :show-inheritance:

    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    .. rubric:: Public Methods

    
    .. automethod:: __init__
    .. automethod:: clear
    .. automethod:: isnan
    .. automethod:: transform
    .. automethod:: update
    


    

    
    .. rubric:: Special Methods

    
    .. automethod:: __bool__
    

    


|

polyfemos.parser.filepathparser
===============================

.. currentmodule:: polyfemos.parser.filepathparser

.. automodule:: polyfemos.parser.filepathparser

   .. comment to end block






    
        
    
    
        
    



.. rubric:: Public Functions


.. autofunction:: path_from_str





.. rubric:: Private Functions


.. autofunction:: _pathfunc




















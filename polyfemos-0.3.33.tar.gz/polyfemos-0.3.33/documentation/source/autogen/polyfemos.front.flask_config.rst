
polyfemos.front.flask_config
============================

.. currentmodule:: polyfemos.front.flask_config

.. automodule:: polyfemos.front.flask_config

   .. comment to end block

















.. rubric:: Classes

.. autosummary::
    :toctree: .
    
    ProductionConfig
















polyfemos.front.sohplot.offsets
===============================

.. currentmodule:: polyfemos.front.sohplot.offsets

.. automodule:: polyfemos.front.sohplot.offsets

   .. comment to end block






    
        
    



.. rubric:: Public Functions


.. autofunction:: init_definitions











.. rubric:: Classes

.. autosummary::
    :toctree: .
    
    UWVOffsets















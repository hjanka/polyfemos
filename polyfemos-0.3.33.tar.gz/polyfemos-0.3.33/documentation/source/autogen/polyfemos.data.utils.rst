
polyfemos.data.utils
====================

.. currentmodule:: polyfemos.data.utils

.. automodule:: polyfemos.data.utils

   .. comment to end block






    
        
    



.. rubric:: Public Functions


.. autofunction:: log10_decimation























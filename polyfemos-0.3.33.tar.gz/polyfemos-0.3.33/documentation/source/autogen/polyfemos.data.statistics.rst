
polyfemos.data.statistics
=========================

.. currentmodule:: polyfemos.data.statistics

.. automodule:: polyfemos.data.statistics

   .. comment to end block






    
        
    
    
        
    



.. rubric:: Public Functions


.. autofunction:: get_statistics_dict
.. autofunction:: get_statistics_table























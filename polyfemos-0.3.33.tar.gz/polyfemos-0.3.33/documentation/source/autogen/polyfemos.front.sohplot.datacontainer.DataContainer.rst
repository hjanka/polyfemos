
polyfemos.front.sohplot.datacontainer.DataContainer
===================================================

.. currentmodule:: polyfemos.front.sohplot.datacontainer

.. autoclass:: DataContainer
    :show-inheritance:

    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    .. rubric:: Public Methods

    
    .. automethod:: __init__
    .. automethod:: add2info
    .. automethod:: add_identical_removal_info
    .. automethod:: append
    .. automethod:: count_nans
    .. automethod:: decimate
    .. automethod:: get_info
    .. automethod:: get_ys_wo_nans
    .. automethod:: outlier_removal
    .. automethod:: remove_irrationals
    .. automethod:: sort
    


    

    
    .. rubric:: Special Methods

    
    .. automethod:: __len__
    

    


|
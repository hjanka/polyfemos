
polyfemos.almanac.ordinal.Ordinal
=================================

.. currentmodule:: polyfemos.almanac.ordinal

.. autoclass:: Ordinal
    :show-inheritance:

    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    .. rubric:: Public Methods

    
    .. automethod:: __init__
    .. automethod:: getstr
    .. automethod:: range
    .. automethod:: shiftdays
    .. automethod:: till
    .. automethod:: today
    .. automethod:: utcdatetime
    


    

    
    .. rubric:: Special Methods

    
    .. automethod:: __format__
    .. automethod:: __iadd__
    .. automethod:: __isub__
    

    


|
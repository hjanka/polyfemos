
polyfemos.almanac.ordinal
=========================

.. currentmodule:: polyfemos.almanac.ordinal

.. automodule:: polyfemos.almanac.ordinal

   .. comment to end block

















.. rubric:: Classes

.. autosummary::
    :toctree: .
    
    Ordinal















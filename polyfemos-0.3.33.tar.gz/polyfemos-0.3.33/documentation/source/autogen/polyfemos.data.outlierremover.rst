
polyfemos.data.outlierremover
=============================

.. currentmodule:: polyfemos.data.outlierremover

.. automodule:: polyfemos.data.outlierremover

   .. comment to end block






    
        
    
    
        
    
    
        
    
    
        
    



.. rubric:: Public Functions


.. autofunction:: dtr
.. autofunction:: lipschitz
.. autofunction:: stalta





.. rubric:: Private Functions


.. autofunction:: _get_mask




















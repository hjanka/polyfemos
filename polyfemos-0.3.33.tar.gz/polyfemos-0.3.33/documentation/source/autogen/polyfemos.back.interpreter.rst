
polyfemos.back.interpreter
==========================

.. currentmodule:: polyfemos.back.interpreter

.. automodule:: polyfemos.back.interpreter

   .. comment to end block






    
        
    
    
        
    



.. rubric:: Public Functions


.. autofunction:: check_quit
.. autofunction:: pool_error_callback











.. rubric:: Classes

.. autosummary::
    :toctree: .
    
    Interpreter















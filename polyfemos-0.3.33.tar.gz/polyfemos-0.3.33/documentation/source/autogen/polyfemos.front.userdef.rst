
polyfemos.front.userdef
=======================

.. currentmodule:: polyfemos.front.userdef

.. automodule:: polyfemos.front.userdef

   .. comment to end block






    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    
    
        
    



.. rubric:: Public Functions


.. autofunction:: channel_codes
.. autofunction:: check_network_code
.. autofunction:: datacoveragebrowser_func
.. autofunction:: definitions
.. autofunction:: filepathformats
.. autofunction:: get_datacoveragebrowser_func
.. autofunction:: get_network_code
.. autofunction:: get_outlierremfunc
.. autofunction:: network_codes
.. autofunction:: paths
.. autofunction:: secret_key
.. autofunction:: sohpars
.. autofunction:: station_ids
.. autofunction:: summary_outlierremfunc_info
.. autofunction:: summary_outlierremfuncs
.. autofunction:: ticklabels
.. autofunction:: transform_func
.. autofunction:: users






















